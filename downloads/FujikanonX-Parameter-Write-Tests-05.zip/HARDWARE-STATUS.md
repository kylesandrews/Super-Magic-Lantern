# Camera validation record

User-reported on 2026-10-17; observations supplied in chat, not independently
instrumented. Target confirmed by user: original EOS 5D, Canon firmware 1.1.1.

- Original Beta 4 installation: boot/capture/shutdown reported confirmed.
- Rebuilt historical baseline: reported working.
- FujikanonX UI test 01: boot, recipe menu and navigation reported working.
- Recipe shortcut check: reported working following requested checks for
  cycling, wraparound, playback behavior and persistence; no detailed logs.
- Startup logo: reported working and loading "very quickly"; no timings.
- Canon screenshot: User Def. 1 based on Standard, sharpness 3, contrast,
  saturation and tone at 0. Firmware property IDs/lengths are not validated
  by the screenshot.

Picture Style diagnostic 01: user supplied a photograph showing it boots and
renders its screen. Active packet was marked seen and raw style was 00000021.
User Def. 1 packet was marked bad size; actual length/count were obscured by
unsupported unsigned-decimal formatting (literal u). No parameter decoding or
write support is validated by this result.

Picture Style diagnostic 02 is a NEW build. Hardware status: NOT TESTED.
Recipe effects, write acknowledgments, rollback of Picture Style settings,
JPEG-only enforcement and color calibration remain unvalidated/unimplemented.
Do not mark new builds hardware-tested based on the UI-test report above.

Diagnostic 02 photographs confirmed active code 0x21, length 4 and count 1;
User Def. 1 subscription returned length 4, count 1 and four zero bytes.
The requested manual sharpness comparison produced no newly observed message
on that subscription. See [source investigation](5d-picture-style-investigation.md).

Canon 1.1.1 package offline analysis identified four separate User Def. 1
scalar properties. Diagnostic 03: NOT YET HARDWARE TESTED. See the investigation
report for address evidence, input hashes and checksum limitations.

Diagnostic 03 user photographs now show all four four-byte scalar readings
matching the original Canon menu: contrast 0, sharpness 3, saturation 0, tone 0.
A requested manual sharpness 3→4 comparison showed sharpness 4 and count 2;
other parameter counts stayed 1. Active style remained 0x21 (its count also rose).
A manual contrast 0→-1 comparison showed -1 / ffffffff / count 2, sharpness 3.
A later photograph showed saturation -1 / ffffffff and tone +1 / 00000001,
both count 2, with contrast 0 and sharpness 3. These last two changes appeared
together; no isolated one-at-a-time result is claimed for them. The user was
instructed to restore both to 0. Full ranges and writes are not yet validated.

Sharpness write test 04: NOT YET HARDWARE TESTED. Adds explicit manual writes
for User Def. 1 sharpness 3→4→3 only, with acknowledgment checks and restoration.
No recipe application or other parameter writes enabled by this new action.

Sharpness write test 04: user photo reports PASS — saw 4, then restored 3.
The user subsequently confirmed Canon's native User Def. 1 menu showed 3.
This validates the tested sharpness 3→4→3 round trip, not full ranges,
other writes, JPEG rendering or the production recipe backend.

Parameter write tests 05: NEW BUILD, NOT YET HARDWARE TESTED. Three separate
confirmed actions add contrast 0→-1→0, saturation 0→-1→0 and color tone 0→1→0.
Sharpness test is retained. Each needs independent result and Canon comparison.
