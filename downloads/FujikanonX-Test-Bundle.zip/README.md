# FujikanonX — original installation files and experimental test builds

Target: original Canon EOS 5D, Canon firmware 1.1.1 only.

Start by extracting this bundle on a computer, then run `python3 VERIFY.py`
(or `sha256sum -c SHA256SUMS`). A successful check validates file integrity,
not camera safety or compatibility.

## Your camera has no Magic Lantern installed

Read **FIRST-INSTALL.md** first. The original supplied Beta 4 ZIP is in
`original-release/`. It includes its original two FIR files and support files.
The first-time installation sequence still needs verification against the
original 5D-specific instructions. This bundle does not automate installation,
write boot flags, or replace Canon's firmware.

Do not copy this entire bundle to the card. Do not run a test `autoexec.bin`
through Canon's Firmware Update menu. Only the original installation files
are FIR files; they remain inside the unchanged original archive.

## Test in stages after establishing the original release

| Stage | Files | Purpose |
|---|---|---|
| Original Beta 4 | original-release/magiclantern-5Dc.111.Beta4.zip | Establish original installation and working recovery card |
| Rebuilt baseline | baseline/autoexec.bin | Check the historical source with the current compiler |
| FujikanonX | candidate/autoexec.bin | Test recipe-first menus, shortcut and optional logo |
| Original binary backup | recovery/original-beta4/autoexec.bin | Restore original card software; not a boot-flag uninstaller |

Follow **UI-TEST-GUIDE.md** only after the original installation works.
That guide's restriction against FIR files applies to the boot/UI test stage;
the original installation archive is included separately in this full bundle.

`support/ML/` contains original support files. `source/` includes source and
build instructions; `build-logs/` and the JSON manifests record provenance.
`TEST-RESULTS.md` provides the camera checklist. Licenses and upstream credits
are preserved. The original archive and all three binaries are checksum-verified.

All new binaries are hardware-untested. Recipes currently select previews;
film rendering and automatic JPEG-only saving remain unavailable.
