# First installation: original EOS 5D, firmware 1.1.1

Your reported camera/version matches this project's target. You reported that
Magic Lantern is not installed. This bundle contains the original installation
files, but **the first-install procedure has not been verified**. Do not use
the FujikanonX candidate as a first-time installer.

## Included original release

`original-release/magiclantern-5Dc.111.Beta4.zip` is an exact, unchanged copy
of the supplied Beta 4 archive. Its SHA-256 is:

```
721d6c3596f5ef0b03a05e854c7d57ebdc0b52deb6b64e75f4cfea8a5b265179
```

It includes the original `autoexec.bin`, ML support files,
`5dc.111.ML_INSTALL.fir` and `5dc.111.card_bootable.fir`. These names and bytes
are preserved. Packaging them does not establish that their installation or
recovery behavior has been validated. They are not rebuilt or rebranded.

## What is established, and what remains

The historical source at commit
`0434b066a870ceca7919bba9a34be30835f04046` includes
`installer/5DC.111/bootdisk.c`. Its `toggle_bootdisk()` routine changes the
camera boot flag and requests a bootable card. The comments describe solid
blue as enabled, blinking blue as disabled, and red as an error. This is
source evidence, not a verified byte-for-byte match to either supplied FIR.
Do not infer a complete installation sequence or removal procedure from it.
In particular, repeatedly running an installer may toggle a flag back.

The original release's `ML/README` warns that a bootable card with the camera
boot flag set but no valid AUTOEXEC.BIN can hang, and recommends promptly
removing the battery if the camera locks up. Deleting AUTOEXEC.BIN is therefore
not a reliable way to uninstall this port.

Before running any FIR, obtain the original **5D Classic / firmware 1.1.1 /
Beta 4** installation instructions and verify the exact order, expected LED
behavior, card preparation, completion/power-off procedure, and boot-flag
removal/recovery method. General instructions for newer EOS models are not
sufficient. Upstream starting points:

- https://wiki.magiclantern.fm/install
- https://wiki.magiclantern.fm/5d
- https://www.magiclantern.fm/forum/

These sites returned access-denied responses from this development environment;
their current instructions could not be inspected. No installation sequence
is claimed verified in this bundle. First-time boot-flag changes can make the
camera unusable; the experimental binaries also remain hardware-untested.

## After a verified original installation

1. Establish the original release boots, captures, reviews, and shuts down
   normally. Keep that working card unchanged and back it up.
2. Use a separate known-working bootable test card for the compiled baseline.
3. Follow `UI-TEST-GUIDE.md`: test `baseline/autoexec.bin` first, then
   `candidate/autoexec.bin`, with the logo and shortcut initially disabled.
4. Record results in `TEST-RESULTS.md`.

The new firmware currently tests recipe selection, menus and logo only.
Film effects and automatic JPEG-only enforcement are not implemented.
