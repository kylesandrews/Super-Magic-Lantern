# Camera validation record

User-reported on 2026-10-17; observations supplied in chat, not independently
instrumented. Target confirmed by user: original EOS 5D, Canon firmware 1.1.1.

- Original Beta 4 installation: boot/capture/shutdown reported confirmed.
- Rebuilt historical baseline: reported working.
- FujikanonX UI test 01: boot, recipe menu and navigation reported working.
- Recipe shortcut check: reported working following requested checks for
  cycling, wraparound, playback behavior and persistence; no detailed logs.
- Startup logo: reported working and loading "very quickly"; no timings.
- Canon screenshot: User Def. 1 based on Standard, sharpness 3, contrast,
  saturation and tone at 0. Firmware property IDs/lengths are not validated
  by the screenshot.

Picture Style diagnostic 01: user supplied a photograph showing it boots and
renders its screen. Active packet was marked seen and raw style was 00000021.
User Def. 1 packet was marked bad size; actual length/count were obscured by
unsupported unsigned-decimal formatting (literal u). No parameter decoding or
write support is validated by this result.

Picture Style diagnostic 02 is a NEW build. Hardware status: NOT TESTED.
Recipe effects, write acknowledgments, rollback of Picture Style settings,
JPEG-only enforcement and color calibration remain unvalidated/unimplemented.
Do not mark new builds hardware-tested based on the UI-test report above.
