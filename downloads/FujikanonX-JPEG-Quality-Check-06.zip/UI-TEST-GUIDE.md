# FujikanonX first camera test

Status: experimental **UI/boot test**, not a camera-ready release. Target:
**original Canon EOS 5D (5D Classic), Canon firmware 1.1.1**. These binaries
are not for the 5D Mark II/III/IV or any other camera. Recipes select names
and previews only; this test cannot validate film rendering or JPEG-only enforcement.
The inherited tools can still change camera settings.

## 1. Confirm the camera before copying anything

Record the exact model and Canon firmware version from the camera menu.
Confirm that the original Magic Lantern Beta 4 already boots successfully
from a known-working CF card. If either the version or existing installation
is uncertain, stop here and report it. This package provides no first-time
installer or boot-flag procedure. Do not select Canon's firmware-update menu
for any of these test binaries.

Use a fully charged battery and a spare, already-working bootable test card.
Keep the working card unchanged. Back up the test card's entire contents,
including its original `autoexec.bin`, `ML` directory and configuration; record
its original hash. A file copy alone does not make another card bootable.
Keep a separate ordinary non-bootable card available for Canon-only operation.

A bootable card with the camera's boot flag set but no valid `autoexec.bin`
can hang this historical 5D port. Do not use deleting that file as a recovery
method. If the camera locks up, remove the battery promptly, remove the test
card, and restore the known-working card/binary before trying again. Do not
keep retrying a failing build or alter boot flags to troubleshoot it.

## 2. Verify the extracted package

The ZIP contains **separate** binary choices, never an installation image:

- `baseline/autoexec.bin`: freshly compiled historical source, without new UI.
- `candidate/autoexec.bin`: FujikanonX recipe-first prototype.
- `recovery/original-beta4/autoexec.bin`: untouched binary from the supplied ZIP.
- `support/ML/`: original support files, provided for reference/recovery.
- `source/`: pinned upstream source plus this project's corresponding source.
- `baseline.json`, `candidate.json`: compiler, source, hashes and limitations.

Run `python3 VERIFY.py` inside the extracted directory (Python 3), or
`sha256sum -c SHA256SUMS` on Linux. Both must report success. Copy **only one
selected** `autoexec.bin` to the test card's root; preserve the filename.
Do not copy the package's directory tree wholesale to the card. Preserve the
working ML support files. No `.fir` files are included or needed for this test.

## 3. Establish the compiler baseline

First confirm a normal boot, menu, capture and shutdown using the unchanged
original release. Record observations in `TEST-RESULTS.md`.

Power off and wait for all card activity to finish before removing the card.
On the computer, replace the test card's root `autoexec.bin` with
`baseline/autoexec.bin`. Verify the copied file's SHA-256 against `baseline.json`.
Boot once. Check Canon controls, open/close the firmware menu, take one test
photo and review it, then shut down normally. Stop and restore the original
if this comparison fails. The baseline uses GCC 14 compatibility overrides;
compilation does not validate its low-level assumptions.

## 4. Test FujikanonX, with the splash initially disabled

Only after the baseline passes, power off and replace the root binary with
`candidate/autoexec.bin`. Verify its copied hash against `candidate.json`.
Back up `ML/SETTINGS/magic.cfg`. In that file, set the existing
`fkc.startup.logo` and `sml.recipe.button` entries to `0`, or add each once if
absent, using this syntax (plain text, with final newline):

```
fkc.startup.logo = 0
sml.recipe.button = 0
```

Keep other settings unchanged and record them. These two keys are understood
by the candidate; no default configuration replacement is supplied.

1. Boot; record startup time and unexpected LED/display behavior.
2. From shooting idle, press **DELETE/TRASH** to open the firmware menu.
   Acknowledge the inherited beta warning using its on-screen instructions.
   Film recipes should appear first. The 5D has no Live View.
3. Up/down or dial selects entries; left/right changes pages. Confirm original
   recipe names and variants, including both BASESETS entries at the end.
4. SET opens details; another SET reports unavailable/not applied. Confirm
   no claim that a look was applied. MENU backs through details to the list.
5. MENU from the list opens Main menu. Choose **Other Tools** and SET.
   Browse categories, open **Prefs**, then MENU at its top level should return
   to Other Tools. Existing submenu controls still apply inside submenus.
   Avoid diagnostics, formatting, boot flags and unrelated setting changes.
6. Return to Film recipes. Half-press the shutter to leave the menu; confirm
   normal Canon controls, capture and playback still work.
7. In Other Tools → Prefs, set Recipe button to JUMP. Exit to shooting idle.
   Press JUMP slowly, more than 300 ms apart; selections should advance and
   wrap through all 26 current entries. Menus, playback and half-shutter must
   retain their usual controls. A name notice appears only if the LCD is on.
8. Exit menus and wait at least two seconds with the camera idle to allow
   existing configuration autosave. Shut down and reboot. Confirm selection
   persistence if Config Autosave is enabled; record that setting.
9. As a separate test, enable Other Tools → Prefs → Startup logo, exit and
   let configuration save, then reboot. Check logo dismissal, normal capture
   access and shutdown. Disable it again if behavior is unexpected.

For a file-saving smoke test, manually choose JPEG-only in Canon's own menu
and inspect the resulting card files. This verifies Canon's current setting,
**not** automatic JPEG-only enforcement or a recipe effect.

## 5. Stop conditions and rollback

Stop on any hang, abnormal heat, unexpected continuous card activity,
corrupted files, unresponsive shutter or altered settings you cannot explain.
For a hang, remove the battery promptly. Otherwise power off normally and
wait for card activity to end. Remove the test card. On the computer restore
the exact backed-up original `autoexec.bin`, ML files and configuration; verify
the original hash. Use the untouched known-working card for the next check.
A plain non-bootable card can check Canon-only operation independently.
This restores card software; it is not a guarantee of recovery from every
experimental-firmware failure.

Return the completed results sheet and any screen photographs or exact error
messages. Do not publish this as a tested release until the camera checks pass.
