# FujikanonX camera test results

- Date / tester:
- Exact camera model:
- Canon firmware version:
- Original Beta 4 already booted successfully:
- Card make/capacity and known-working bootable status:
- Original autoexec.bin SHA-256:
- Package SHA-256 verification result:
- Baseline build SHA-256:
- Candidate build SHA-256:
- Existing configuration backup location:
- Config Autosave enabled:

Record PASS / FAIL / NOT RUN and observations for each:

| Check | Result | Observation |
|---|---|---|
| Original release: boot/menu/capture/shutdown | NOT RUN | |
| Compiled baseline: boot/menu/capture/shutdown | NOT RUN | |
| Candidate boot with splash/shortcut disabled | NOT RUN | |
| Recipes open first after beta warning | NOT RUN | |
| Names/variants, paging, details, unavailable notice | NOT RUN | |
| Other Tools, Prefs and return navigation | NOT RUN | |
| Half-shutter exit and normal Canon controls | NOT RUN | |
| JUMP cycling, wraparound, context guards | NOT RUN | |
| Selection persistence with autosave | NOT RUN | |
| Optional logo enable/dismiss/disable | NOT RUN | |
| Canon manual JPEG-only capture/file review | NOT RUN | |
| Normal shutdown and restore original card files | NOT RUN | |

Startup timing (same card/settings, repeat three times per build):

- Define endpoint, e.g. power-on to first responsive shutter:
- Original release:
- Compiled baseline:
- Candidate, logo OFF:
- Candidate, logo ON:

Unexpected behavior, file names, exact messages, and reproduction steps:

Recipe color effects and automatic JPEG-only behavior: NOT IMPLEMENTED / NOT TESTED.
