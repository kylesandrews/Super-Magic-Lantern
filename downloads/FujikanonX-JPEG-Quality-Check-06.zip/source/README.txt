Corresponding source: upstream-source.tar is git archive of commit 0434b066a870ceca7919bba9a34be30835f04046.
Extract fujikanonx-project.tar.gz into a development directory. Initialize
a local Git repository from upstream-source.tar and commit its contents.
The exact pinned commit remains available from the upstream URL in the
build manifests; tools/build.py uses that commit, not the new local commit.
Follow README.md to provision the verified Debian compiler, run make test,
then tools/build.py --mode both --output .build/test-run. The build fetches
the pinned upstream commit and applies the included source and hooks.
Build logs and manifests record compiler flags/provenance; these builds
are not claimed byte reproducible or camera validated.
