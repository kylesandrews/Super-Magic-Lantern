#!/usr/bin/env python3
from pathlib import Path
import hashlib
root = Path(__file__).resolve().parent
count = 0
for line in (root / 'SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    path = root / name
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit('FAILED: ' + name)
    count += 1
print('Verified %d files. Hardware compatibility is NOT verified.' % count)
